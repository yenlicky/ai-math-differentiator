const $ = (id) => document.getElementById(id);
let level = "core";
let currentQuestions = [];
let hintsVisible = false;

const levelLabels = { support: "Support pathway", core: "Core pathway", challenge: "Challenge pathway" };
const levelDescriptions = {
  support: "Scaffolded practice with simpler numbers and smaller steps.",
  core: "Grade-level practice with a balanced mix of skills.",
  challenge: "Multi-step questions that encourage reasoning and transfer."
};
const supportDescriptions = {
  standard: "Balanced practice with feedback after checking.",
  steps: "Short hints break a method into manageable steps.",
  visual: "Questions connect mathematics to graphs or real-life situations.",
  extension: "Prompts encourage justification and deeper reasoning."
};

const banks = {
  quadratic: {
    title: "Quadratic functions",
    desc: "Practice identifying key features and interpreting quadratic expressions.",
    questions: {
      support: [
        {p:"For the function below, what is the value of c (the y-intercept)?", math:"y = x² + 3x + 2", a:["2"], hint:"In y = ax² + bx + c, c is the constant term.", explain:"The constant term is c = 2."},
        {p:"Does this parabola open upward or downward?", math:"y = 2x² − 1", a:["up","upward"], hint:"Look at the coefficient a in front of x².", explain:"Since a = 2 is positive, it opens upward."},
        {p:"What is the value of a?", math:"y = −3x² + x + 5", a:["-3","−3"], hint:"a is the coefficient multiplying x².", explain:"The coefficient of x² is −3."},
        {p:"Find y when x = 0.", math:"y = x² − 4x + 6", a:["6"], hint:"Substitute x = 0; terms containing x become zero.", explain:"At x = 0, y = 6."}
      ],
      core: [
        {p:"For the function below, identify the y-intercept.", math:"y = 2x² − 5x + 4", a:["4","(0,4)","0,4"], hint:"The y-intercept occurs when x = 0.", explain:"When x = 0, y = 4, so the y-intercept is (0, 4)."},
        {p:"Does the graph open upward or downward? Give the direction.", math:"y = −x² + 6x − 2", a:["down","downward"], hint:"The sign of a determines the direction.", explain:"Because a = −1 is negative, the parabola opens downward."},
        {p:"Calculate f(2).", math:"f(x) = x² + 2x − 3", a:["5"], hint:"Replace every x with 2: 2² + 2(2) − 3.", explain:"f(2) = 4 + 4 − 3 = 5."},
        {p:"Find the axis of symmetry.", math:"y = x² − 6x + 5", a:["x=3","x = 3","3"], hint:"For y = ax² + bx + c, the axis is x = −b/(2a).", explain:"x = −(−6)/(2·1) = 3."},
        {p:"What is the y-intercept of y = 3x² + x − 7?", math:"y = 3x² + x − 7", a:["-7","−7","(0,-7)"], hint:"Set x = 0.", explain:"The y-intercept is (0, −7)."}
      ],
      challenge: [
        {p:"Find the x-coordinate of the vertex.", math:"y = 2x² − 8x + 1", a:["2","x=2","x = 2"], hint:"Use x = −b/(2a). Here a = 2 and b = −8.", explain:"x = 8/4 = 2."},
        {p:"Find the minimum value of the function.", math:"y = x² − 4x + 1", a:["-3","−3"], hint:"Complete the square: x² − 4x + 1 = (x − 2)² − 3.", explain:"The squared term is at least 0, so the minimum is −3."},
        {p:"A parabola has a = −2. What is its opening direction, and why?", math:"y = −2x² + bx + c", a:["down","downward","down because a is negative","downward because a is negative"], hint:"A negative leading coefficient makes the parabola open downward.", explain:"It opens downward because a < 0."},
        {p:"Find the axis of symmetry.", math:"y = 3x² + 12x + 4", a:["x=-2","x = -2","-2"], hint:"Use x = −b/(2a).", explain:"x = −12/(2·3) = −2."}
      ]
    }
  },
  linear: {
    title: "Linear equations",
    desc: "Solve equations and interpret slope-intercept form.",
    questions: {
      support: [
        {p:"Solve for x.", math:"x + 5 = 12", a:["7"], hint:"Subtract 5 from both sides.", explain:"x = 12 − 5 = 7."},
        {p:"Solve for x.", math:"3x = 18", a:["6"], hint:"Divide both sides by 3.", explain:"x = 6."},
        {p:"What is the y-intercept?", math:"y = 2x + 4", a:["4","(0,4)"], hint:"In y = mx + b, b is the y-intercept.", explain:"The y-intercept is 4."},
        {p:"Solve for x.", math:"x − 3 = 8", a:["11"], hint:"Add 3 to both sides.", explain:"x = 11."}
      ],
      core: [
        {p:"Solve for x.", math:"4x − 7 = 13", a:["5"], hint:"Add 7, then divide by 4.", explain:"4x = 20, so x = 5."},
        {p:"Identify the slope m.", math:"y = −3x + 8", a:["-3","−3"], hint:"The coefficient of x is the slope.", explain:"The slope is −3."},
        {p:"Find y when x = 4.", math:"y = 2x − 1", a:["7"], hint:"Substitute x = 4.", explain:"y = 2(4) − 1 = 7."},
        {p:"Solve for x.", math:"2(x + 3) = 16", a:["5"], hint:"Divide by 2 first, then subtract 3.", explain:"x + 3 = 8, so x = 5."},
        {p:"A line has slope 2 and y-intercept −1. Write its equation.", math:"y = mx + b", a:["y=2x-1","y = 2x - 1","y=2x−1"], hint:"Put m = 2 and b = −1 into y = mx + b.", explain:"The equation is y = 2x − 1."}
      ],
      challenge: [
        {p:"Solve for x.", math:"3(2x − 1) = 4x + 9", a:["6"], hint:"Expand brackets, collect x terms, then solve.", explain:"6x − 3 = 4x + 9, so 2x = 12 and x = 6."},
        {p:"Find the intersection x-coordinate.", math:"y = 2x + 1 and y = −x + 7", a:["2"], hint:"Set the expressions equal to each other.", explain:"2x + 1 = −x + 7 gives 3x = 6, so x = 2."},
        {p:"A line passes through (1, 4) and (3, 10). Find its slope.", math:"m = (y₂ − y₁)/(x₂ − x₁)", a:["3"], hint:"Use (10 − 4)/(3 − 1).", explain:"m = 6/2 = 3."}
      ]
    }
  },
  fractions: {
    title: "Fractions",
    desc: "Build fluency with equivalent fractions and fraction operations.",
    questions: {
      support: [
        {p:"Simplify the fraction.", math:"4/8", a:["1/2","0.5"], hint:"Divide the numerator and denominator by 4.", explain:"4/8 = 1/2."},
        {p:"Calculate.", math:"1/4 + 1/4", a:["1/2","2/4"], hint:"The denominators are already equal.", explain:"1/4 + 1/4 = 2/4 = 1/2."},
        {p:"What is half of 10?", math:"1/2 × 10", a:["5"], hint:"Divide 10 by 2.", explain:"Half of 10 is 5."}
      ],
      core: [
        {p:"Calculate and simplify.", math:"1/3 + 1/6", a:["1/2","3/6"], hint:"Use denominator 6.", explain:"2/6 + 1/6 = 3/6 = 1/2."},
        {p:"Calculate.", math:"3/4 − 1/8", a:["5/8"], hint:"Convert 3/4 to eighths.", explain:"6/8 − 1/8 = 5/8."},
        {p:"Calculate and simplify.", math:"2/3 × 3/5", a:["2/5"], hint:"Multiply numerators and denominators, then simplify.", explain:"6/15 = 2/5."},
        {p:"Calculate.", math:"3/4 ÷ 1/2", a:["3/2","1.5"], hint:"Multiply by the reciprocal of 1/2.", explain:"3/4 × 2/1 = 6/4 = 3/2."}
      ],
      challenge: [
        {p:"Calculate and simplify.", math:"(2/3 + 1/4) ÷ 11/12", a:["1"], hint:"First add 2/3 + 1/4, then divide by 11/12.", explain:"8/12 + 3/12 = 11/12; dividing by 11/12 gives 1."},
        {p:"A recipe uses 3/4 cup of milk per batch. How much is needed for 2 1/2 batches?", math:"3/4 × 5/2", a:["15/8","1 7/8","1.875"], hint:"Convert 2 1/2 to 5/2, then multiply.", explain:"3/4 × 5/2 = 15/8 = 1 7/8 cups."}
      ]
    }
  },
  percent: {
    title: "Percentages",
    desc: "Calculate percentages, changes, and real-world amounts.",
    questions: {
      support: [
        {p:"Find 10% of 50.", math:"0.10 × 50", a:["5"], hint:"10% means one tenth.", explain:"10% of 50 is 5."},
        {p:"Write 25% as a decimal.", math:"25%", a:["0.25",".25"], hint:"Divide the percentage by 100.", explain:"25% = 0.25."},
        {p:"A $20 item has a 50% discount. How much is the discount?", math:"50% of $20", a:["10","$10"], hint:"50% is one half.", explain:"The discount is $10."}
      ],
      core: [
        {p:"Find 15% of 80.", math:"0.15 × 80", a:["12"], hint:"Convert 15% to 0.15, then multiply.", explain:"0.15 × 80 = 12."},
        {p:"A price rises from $40 to $50. Find the percentage increase.", math:"(change ÷ original) × 100%", a:["25","25%"], hint:"The increase is $10; compare it to the original $40.", explain:"10/40 × 100% = 25%."},
        {p:"A $60 jacket is discounted by 20%. What is the sale price?", math:"$60 − 20% of $60", a:["48","$48"], hint:"Find 20% of 60, then subtract it.", explain:"20% of 60 is 12, so the sale price is $48."},
        {p:"Convert 0.72 to a percentage.", math:"0.72 × 100%", a:["72","72%"], hint:"Multiply the decimal by 100.", explain:"0.72 = 72%."}
      ],
      challenge: [
        {p:"A value increases by 20%, then decreases by 20%. What is the final value if it starts at 100?", math:"100 × 1.20 × 0.80", a:["96"], hint:"Apply each percentage change in sequence.", explain:"120 × 0.8 = 96, so the final value is 96."},
        {p:"After a 15% discount, a product costs $68. What was its original price?", math:"0.85 × original = 68", a:["80","$80"], hint:"Divide 68 by 0.85.", explain:"68 ÷ 0.85 = $80."}
      ]
    }
  },
  probability: {
    title: "Probability",
    desc: "Express probabilities and reason about simple events.",
    questions: {
      support: [
        {p:"A fair coin is tossed. What is the probability of heads?", math:"P(heads) = ?", a:["1/2","0.5"], hint:"There are two equally likely outcomes.", explain:"P(heads) = 1/2."},
        {p:"A fair six-sided die is rolled. What is the probability of rolling a 6?", math:"P(6) = ?", a:["1/6"], hint:"One outcome out of six is a 6.", explain:"P(6) = 1/6."},
        {p:"A bag has 3 red and 1 blue counter. What is P(blue)?", math:"1 blue out of 4 counters", a:["1/4","0.25"], hint:"Probability = favorable outcomes / total outcomes.", explain:"P(blue) = 1/4."}
      ],
      core: [
        {p:"A fair die is rolled. Find the probability of an even number.", math:"Outcomes: 1, 2, 3, 4, 5, 6", a:["1/2","3/6","0.5"], hint:"Even outcomes are 2, 4, and 6.", explain:"There are 3 even outcomes out of 6, so 1/2."},
        {p:"A bag has 4 green and 6 yellow counters. Find P(green).", math:"4 green, 10 total", a:["2/5","4/10","0.4"], hint:"Use 4/10 and simplify.", explain:"P(green) = 4/10 = 2/5."},
        {p:"Two fair coins are tossed. What is P(two heads)?", math:"HH, HT, TH, TT", a:["1/4","0.25"], hint:"Only one of the four equally likely outcomes is HH.", explain:"P(two heads) = 1/4."},
        {p:"If P(A) = 0.3, what is P(not A)?", math:"P(not A) = 1 − P(A)", a:["0.7"], hint:"An event and its complement add to 1.", explain:"1 − 0.3 = 0.7."}
      ],
      challenge: [
        {p:"A fair die is rolled twice. Find the probability of getting two sixes.", math:"P(6 then 6)", a:["1/36"], hint:"For independent events, multiply their probabilities.", explain:"1/6 × 1/6 = 1/36."},
        {p:"A bag has 3 red and 2 blue counters. Two counters are drawn without replacement. Find P(two red).", math:"3/5 × 2/4", a:["3/10","0.3"], hint:"After drawing a red, 2 red counters remain out of 4.", explain:"3/5 × 2/4 = 6/20 = 3/10."}
      ]
    }
  },
  pythagorean: {
    title: "Pythagorean theorem",
    desc: "Find missing sides in right triangles using a² + b² = c².",
    questions: {
      support: [
        {p:"A right triangle has legs 3 and 4. Find the hypotenuse.", math:"c² = 3² + 4²", a:["5"], hint:"3² + 4² = 9 + 16 = 25.", explain:"c = √25 = 5."},
        {p:"What is the hypotenuse called in the formula?", math:"a² + b² = c²", a:["c"], hint:"The hypotenuse is opposite the right angle.", explain:"The hypotenuse is c."},
        {p:"Find c.", math:"a = 6, b = 8", a:["10"], hint:"c = √(6² + 8²).", explain:"c = √100 = 10."}
      ],
      core: [
        {p:"Find the hypotenuse of a right triangle with legs 5 and 12.", math:"c² = 5² + 12²", a:["13"], hint:"25 + 144 = 169.", explain:"c = √169 = 13."},
        {p:"The hypotenuse is 10 and one leg is 6. Find the other leg.", math:"b² = 10² − 6²", a:["8"], hint:"Subtract the square of the known leg from 10².", explain:"b = √(100 − 36) = 8."},
        {p:"Is a triangle with sides 7, 24, 25 right-angled? Answer yes or no.", math:"7² + 24² = 25² ?", a:["yes","y"], hint:"Check whether 49 + 576 equals 625.", explain:"Yes. 49 + 576 = 625."},
        {p:"Find the diagonal of a rectangle with sides 9 cm and 12 cm.", math:"d² = 9² + 12²", a:["15","15 cm"], hint:"Treat the diagonal as the hypotenuse.", explain:"d = √225 = 15 cm."}
      ],
      challenge: [
        {p:"A ladder reaches 12 m up a wall. Its base is 5 m from the wall. Find the ladder length.", math:"L² = 12² + 5²", a:["13","13 m"], hint:"The ladder is the hypotenuse.", explain:"L = √169 = 13 m."},
        {p:"A right triangle has hypotenuse 17 and one leg 8. Find the other leg.", math:"b² = 17² − 8²", a:["15"], hint:"289 − 64 = 225.", explain:"b = √225 = 15."}
      ]
    }
  }
};

function normalizeAnswer(value) {
  return String(value).toLowerCase().trim().replace(/[−–]/g, "-").replace(/\s+/g, "").replace(/[$%]/g, "");
}
function chooseQuestions() {
  const topic = $("topic").value;
  const pool = [...banks[topic].questions[level]];
  // Shuffle in-place so repeated generation gives a different order/selection.
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  const count = Math.min(Number($("count").value), pool.length);
  currentQuestions = pool.slice(0, count).map((q, i) => ({...q, id: `${Date.now()}-${i}-${Math.random()}`}));
  renderQuestions();
  updateSnapshot();
}
function renderQuestions() {
  const topic = banks[$("topic").value];
  $("setTitle").textContent = `${topic.title} · ${level[0].toUpperCase()+level.slice(1)}`;
  $("setDescription").textContent = topic.desc;
  $("questionCount").textContent = `${currentQuestions.length} QUESTION${currentQuestions.length === 1 ? "" : "S"}`;
  $("result").textContent = "";
  $("taskList").classList.toggle("show-hints", hintsVisible);
  $("taskList").innerHTML = currentQuestions.map((q, i) => `
    <article class="question" data-id="${q.id}">
      <div class="question-top"><span class="q-label">QUESTION ${String(i+1).padStart(2,"0")}</span><span class="tag">${level === "support" ? "Guided" : level === "challenge" ? "Challenge" : "Core skill"}</span></div>
      <p class="prompt">${q.p}</p>
      <div class="math">${q.math}</div>
      <div class="answer-row"><input type="text" aria-label="Answer to question ${i+1}" data-answer="${q.id}" placeholder="Type your answer"><button type="button" class="secondary reveal" data-reveal="${q.id}">Reveal</button></div>
      <p class="feedback" data-feedback="${q.id}"></p>
      <p class="hint-text"><strong>Hint:</strong> ${q.hint}</p>
    </article>`).join("");
  $("taskList").querySelectorAll("[data-reveal]").forEach(btn => btn.addEventListener("click", () => revealAnswer(btn.dataset.reveal)));
}
function revealAnswer(id) {
  const q = currentQuestions.find(item => item.id === id);
  if (!q) return;
  const input = document.querySelector(`[data-answer="${id}"]`);
  input.value = q.a[0];
  const feedback = document.querySelector(`[data-feedback="${id}"]`);
  feedback.textContent = `Answer shown. ${q.explain}`;
  feedback.className = "feedback";
}
function updateSnapshot() {
  $("levelName").textContent = levelLabels[level];
  $("levelDesc").textContent = levelDescriptions[level];
  $("supportDesc").textContent = supportDescriptions[$("learner").value];
}
function checkAnswers() {
  let score = 0;
  currentQuestions.forEach(q => {
    const input = document.querySelector(`[data-answer="${q.id}"]`);
    const feedback = document.querySelector(`[data-feedback="${q.id}"]`);
    const val = normalizeAnswer(input.value);
    const correct = q.a.some(a => normalizeAnswer(a) === val);
    input.classList.toggle("correct", correct);
    input.classList.toggle("incorrect", !correct);
    feedback.className = `feedback ${correct ? "good" : "bad"}`;
    feedback.textContent = correct ? `Correct! ${q.explain}` : `Not quite. ${q.explain}`;
    if (correct) score++;
  });
  $("result").textContent = `You got ${score} out of ${currentQuestions.length} correct. ${score === currentQuestions.length ? "Excellent work!" : "Review the feedback and try again."}`;
}
document.querySelectorAll(".level").forEach(btn => btn.addEventListener("click", () => {
  level = btn.dataset.level;
  document.querySelectorAll(".level").forEach(b => b.classList.toggle("active", b === btn));
  chooseQuestions();
}));
$("topic").addEventListener("change", chooseQuestions);
$("learner").addEventListener("change", updateSnapshot);
$("count").addEventListener("input", () => {
  $("countValue").textContent = $("count").value;
});
$("generateBtn").addEventListener("click", chooseQuestions);
$("showHintsBtn").addEventListener("click", () => {
  hintsVisible = !hintsVisible;
  $("taskList").classList.toggle("show-hints", hintsVisible);
  $("showHintsBtn").textContent = hintsVisible ? "Hide hints" : "Show hints";
});
$("resetBtn").addEventListener("click", () => {
  document.querySelectorAll("[data-answer]").forEach(input => {
    input.value = ""; input.classList.remove("correct","incorrect");
  });
  document.querySelectorAll("[data-feedback]").forEach(feedback => {
    feedback.textContent = ""; feedback.className = "feedback";
  });
  $("result").textContent = "";
});
$("checkBtn").addEventListener("click", checkAnswers);
chooseQuestions();
