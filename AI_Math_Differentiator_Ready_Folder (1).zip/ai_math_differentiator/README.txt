AI Math Differentiator — ready-to-upload website

FILES
- index.html: page structure
- style.css: responsive styling
- script.js: task generation, hints, answer checking, and differentiation logic

RUN LOCALLY
1. Extract the ZIP folder.
2. Open index.html in Chrome, Edge, or another modern browser.
3. Choose a math topic and level.
4. Click “Generate new task” to generate a fresh selection of questions.

PUBLISH WITH NETLIFY
1. Go to https://app.netlify.com/drop
2. Extract the ZIP on your computer.
3. Drag the extracted ai_math_differentiator folder (or select its files) onto the Netlify Drop page.
4. Wait for the deployment link, then open it and test the controls.

NOTES
- This is a self-contained demo using built-in question banks; it does not call an external AI API.
- “Generate new task” changes the selected questions/order from the built-in question bank.
- For a school assignment, review the questions and adapt them to your class.
